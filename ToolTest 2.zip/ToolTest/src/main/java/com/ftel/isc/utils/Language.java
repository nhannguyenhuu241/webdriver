package com.ftel.isc.utils;

public class Language {

    public static String TITLE_TOOL = "ISC Automation Tool";
    public static String PERFORM = "Perform";
    public static String CLEAR = "Reset";
    public static String TEST_CASE_1 = "TestCase1";
    public static String TEST_CASE_2 = "TestCase2";
    public static String TEST_CASE_3 = "TestCase3";
    public static String OPEN_WEBSITE = "Open website";
    public static String BASE_URL = "https://staging.fpt.vn/shop";
}
