package com.ftel.isc.testcase.TestCase2;

import com.ftel.isc.by.ByTestCase_1;
import com.ftel.isc.page.TestCase_Page;
import com.ftel.isc.utils.Language;
import com.ftel.isc.utils.Utils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class TestCase2 {

    private static WebDriver driver;
    final int TIME_OUT = 20;


    @BeforeClass
    public static void beforeClass() {
        System.setProperty("webdriver.chrome.driver", "/Users/nhanne/Downloads/ToolTest/src/main/java/com/ftel/isc/driver/chromedriver");
        driver = new ChromeDriver();
        //System.setProperty("webdriver.gecko.driver", "/Users/nhanne/Desktop/ToolTest/src/main/java/com/ftel/isc/geckodriver");
        //driver = new FirefoxDriver();
        driver.get(Language.BASE_URL);
        driver.manage().window().maximize();
        String actualTitle = driver.getTitle();

        String expectedTitle = "FPT Telecom | Đăng Ký Online";
        if (expectedTitle.contentEquals(actualTitle)) {
            System.out.println("Title Passed !");
        } else System.out.println("Title Failed");
    }

    @Test
    public void actionTest() {
        driver.findElement(By.xpath("//*[@id=\"box_internet\"]/div[1]/div/div[1]/div/div[10]/button")).click();
        TestCase_Page page = new TestCase_Page(driver);
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byFullName, 100, "1")) {

            page.typeFullName("Nguyễn Hửu Nhân");
            page.typePhoneNumber("086924122");
            page.typeEmail("nguyennhan.it2412@gmail.com");
            page.typeDistrict();
            waitForTimeOut();
            ByWard(page);
        }
    }

    private void ByWard(TestCase_Page page) {
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byWardList, 100, "2")) {
            // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            page.typeByWardList();
            waitForTimeOut();
            ByTreet(page);
        }
    }

    private void ByTreet(TestCase_Page page) {
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byTreet, 100, "3")) {
            // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            page.typeTreet();
            page.typeHouseNumber("123");
            page.typeSubmitForm();
            waitForTimeOut();

            ByMessage(page);
        }
    }

    private void ByMessage(TestCase_Page page) {
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byErrorPhone, 100, "4")) {
            String textError = driver.findElement(ByTestCase_1.byErrorPhone).getText();
            if (textError.equals("Số điện thoại hợp lệ phải có 10 số.")) {
                System.out.println("\nTest Case Passed");
            } else {
                System.out.println("\nTest Case Failed");
            }
        }
    }

    public void waitForTimeOut() {
        driver.manage().timeouts().implicitlyWait(TIME_OUT, TimeUnit.SECONDS);
    }

    @AfterClass
    public static void afterClass() {
        driver.quit();
    }
}
