package com.ftel.isc.testcase.TestCase4;

import com.ftel.isc.by.ByTestCase_1;
import com.ftel.isc.page.TestCase_Page;
import com.ftel.isc.utils.Language;
import com.ftel.isc.utils.Utils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class TestCase4 {

    //private final JTextArea textArea;
    // private final PrintStream standardOut;
    private static WebDriver driver;
    final int TIME_OUT = 20;

    @BeforeClass
    public static void beforeClass() throws IOException {
        //Create an object of ReadGuru99ExcelFile class

//        Utils reaExels = new Utils();
//
//        //Prepare the path of excel file
//
//        String filePath = "C:\\Users\\PC\\Desktop\\ToolTest\\src\\main\\java\\com\\ftel\\isc\\excelExportAndFileIO";
//
//        //Call read file method of the class to read data
//
//        reaExels.readExcel(filePath,"ExportExcel.xls","Sheet1");


        System.setProperty("webdriver.chrome.driver", "/Users/nhanne/Downloads/ToolTest/src/main/java/com/ftel/isc/driver/chromedriver");
        driver = new ChromeDriver();
        java.util.Set<String> handes = driver.getWindowHandles();
        String winHanddel = driver.getWindowHandle();
        handes.remove(winHanddel);
        //System.setProperty("webdriver.gecko.driver", "/Users/nhanne/Desktop/ToolTest/src/main/java/com/ftel/isc/geckodriver");
        //driver = new FirefoxDriver();
        driver.get(Language.BASE_URL);
        driver.manage().window().maximize();
        String actualTitle = driver.getTitle();

        String expectedTitle = "FPT Telecom | Đăng Ký Online";
        if (expectedTitle.contentEquals(actualTitle)) {
            System.out.println("Title Passed !");
        } else System.out.println("Title Failed");
    }


    @Test
    public void actionTest() throws InterruptedException {
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id=\"box_internet\"]/div[1]/div/div[1]/div/div[10]/button")).click();
        TestCase_Page page = new TestCase_Page(driver);
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byFullName, 200, "1")) {

            page.typeFullName("Nguyễn Hửu Nhân");
            page.typePhoneNumber("0869241224");
            page.typeEmail("nguyennhan.it2412@gmail.com");
            page.typeDistrict();
            Thread.sleep(3000);

            page.typeByWardList();
            Thread.sleep(3000);

            page.typeTreet();
            Thread.sleep(3000);

            page.typeHouseNumber("123");
            Thread.sleep(3000);

            page.typeSubmitForm();
            Thread.sleep(6000);

            page.typeBirtDay("26/10/1997");

            page.typePassport("3418188634");
            // page.typeRadio6Month();
            page.typePaymentCate();
            page.typePayment();
            Thread.sleep(3000);
        }
    }

//    public TestCase1() {
//        textArea = new JTextArea(50, 10);
//        textArea.setEditable(false);
//        PrintStream printStream = new PrintStream(new CustomOutputStream(textArea));
//
//        // keeps reference of standard output stream
//        standardOut = System.out;
//
//        // re-assigns standard output stream and error output stream
//        System.setOut(printStream);
//        System.setErr(printStream);
//        setLayout(new GridBagLayout());
//        GridBagConstraints constraints = new GridBagConstraints();
//        constraints.gridx = 0;
//        constraints.gridy = 0;
//        constraints.insets = new Insets(10, 10, 10, 10);
//        constraints.anchor = GridBagConstraints.WEST;
//
//        JButton buttonStart = new JButton("Start");
//        add(buttonStart, constraints);
//
//        constraints.gridx = 1;
//        JButton buttonClear = new JButton("Clear");
//        add(buttonClear, constraints);
//
//        constraints.gridx = 0;
//        constraints.gridy = 1;
//        constraints.gridwidth = 2;
//        constraints.fill = GridBagConstraints.BOTH;
//        constraints.weightx = 1.0;
//        constraints.weighty = 1.0;
//
//        add(new JScrollPane(textArea), constraints);
//
//        // adds event handler for button Start
//        buttonStart.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent evt) {
//            }
//        });
//        // adds event handler for button Clear
//        buttonClear.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent evt) {
//                // clears the text area
//                try {
//                    textArea.getDocument().remove(0,
//                            textArea.getDocument().getLength());
//                    standardOut.println("Text area cleared");
//                } catch (BadLocationException ex) {
//                    ex.printStackTrace();
//                }
//            }
//        });
//
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setSize(480, 320);
//        setLocationRelativeTo(null);
//    }

    private void ByWard(TestCase_Page page) {
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byWardList, 200, "2")) {
            // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            page.typeByWardList();
            waitForTimeOut();
            ByTreet(page);
        }
    }

    private void ByTreet(TestCase_Page page) {
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byTreet, 200, "3")) {
            // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            page.typeTreet();
            page.typeHouseNumber("123");
            page.typeSubmitForm();
            waitForTimeOut();
            ByBirtday(page);
        }
    }

    private void ByBirtday(TestCase_Page page) {
        if (Utils.waitForElementDisplay(driver, ByTestCase_1.byBirtDay, 500, "trang 3")) {

            page.typeBirtDay("26/10/1997");
            page.typePassport("3418188634");
            // page.typeRadio6Month();
            page.typePaymentCate();
            page.typePayment();
            waitForTimeOut();

        }
    }


    public void waitForTimeOut() {
        driver.manage().timeouts().implicitlyWait(TIME_OUT, TimeUnit.SECONDS);
    }

    @AfterClass
    public static void afterClass() {
        driver.quit();
    }
}
